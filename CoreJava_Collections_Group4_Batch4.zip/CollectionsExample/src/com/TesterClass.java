package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class TesterClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		/*Creating Student objects*/    
	    Student b1=new Student(102,"Yashwanth");    
	    Student b2=new Student(102,"Yashwanth");    
	    Student b3=new Student(101,"Gourav");
	    Student b4=new Student(104,"Harshitha");
	    Student b5=new Student(105,"Sireesha");
		
	    
	    /*ArrayList Creation*/
	    ArrayList<Student> student=new ArrayList<Student>();
		
	    /*Adding Students to list*/ 
		student.add(b1);
		student.add(b2);
		student.add(b3);
		student.add(b4);
		student.add(b5);
		
		/*Traversing Array List*/ 
		System.out.println("ArrayList: ");
		for(Student array:student)
		{
			System.out.println("  "+array.getId()+"  "+array.getName());
		}
		
		
		/*LinkedList Creation*/
		LinkedList<Student> student1=new LinkedList<Student>();
		
		/*Adding Students to list*/
		student1.add(b1);
		student1.add(b2);
		student1.add(b3);
		student1.add(b4);
		student1.add(b5);
		
		/*Traversing Linked List*/
		System.out.println("LinkedList: ");
		for(Student linkedlist:student1)
		{
			System.out.println("  " +linkedlist.getId()+"  "+linkedlist.getName());
		}
		
		
		/*HashSet Creation*/
		HashSet<Student> set=new HashSet<Student>();
		
		/*Adding Students to set*/
		set.add(b1);
		set.add(b2);
		set.add(b3);
		set.add(b4);
		set.add(b5);
		
		/*Traversing Hash Set*/
		System.out.println("HashSet: ");
		for(Student i:set)
		{
			System.out.println("  " +i.getId()+"  "+i.getName());
		}
		
		/*LinkedHashSet Creation*/
		LinkedHashSet<Student> hs=new LinkedHashSet<Student>();
		
		//Adding Students to set
		hs.add(b1);
		hs.add(b2);
		hs.add(b3);
		hs.add(b4);
		hs.add(b5);
		
		/*Traversing Linked Hash Set*/
		System.out.println("LinkedHashSet: ");
		for(Student j:hs)
		{
			System.out.println("  " +j.getId()+"  "+j.getName());
		}
		
		/*TreeSet Creation*/
		TreeSet<Student> set1=new TreeSet<Student>();
				
		/*Adding Students to set*/
		set1.add(b1);
		set1.add(b2);
		set1.add(b3);
		set1.add(b4);
		set1.add(b5);
				
		/*Traversing Tree Set*/
		System.out.println("TreeSet: ");
		for(Student k:set1)
		{
			System.out.println("  " +k.getId()+"  "+k.getName());
		}
		 
		/*HashMap Creation*/
		Map<Integer,Student> map=new HashMap<Integer,Student>();    
		    
		/*Adding Students to map*/   
		map.put(b1.getId(),b1);  
		map.put(b2.getId(),b2);  
		map.put(b3.getId(),b3);
		map.put(b4.getId(),b4);
		map.put(b4.getId(),b4);
		      
		/*Traversing Hash Map*/  
		System.out.println("HashMap: ");
		for(Map.Entry<Integer,Student> entry:map.entrySet())
		{    
			entry.getKey();  
		    Student b=entry.getValue();  
		    System.out.println("  "+b.getId()+"  "+b.getName());   
		}  
		    
		/*LinkedHashMap Creation*/
		Map<Integer,Student> lmap=new LinkedHashMap<Integer,Student>();    
		    
		/*Adding Students to map*/   
		lmap.put(b1.getId(),b1);  
		lmap.put(b2.getId(),b2);  
		lmap.put(b3.getId(),b3);
		lmap.put(b4.getId(),b4);
		lmap.put(b4.getId(),b4);
		      
		/*Traversing Linked Hash Map*/  
		System.out.println("LinkedHashMap: ");
		for(Map.Entry<Integer,Student> entry1:lmap.entrySet())
		{    
		   entry1.getKey();  
		   Student c=entry1.getValue();  
		   System.out.println("  "+c.getId()+"  "+c.getName());   
		}  
		    
		/*TreeMap Creation*/
		Map<Integer,Student> tmap=new TreeMap<Integer,Student>();  
		  
		/*Adding Students to map*/   
		tmap.put(b2.getId(),b2);
		tmap.put(b1.getId(),b1);  
		tmap.put(b3.getId(),b3); 
		tmap.put(b5.getId(),b5);
		tmap.put(b4.getId(),b4);
		      
		/*Traversing Tree Map*/  
		System.out.println("TreeMap: ");
		for(Map.Entry<Integer,Student> entry1:tmap.entrySet())
		{    
			entry1.getKey();  
		    Student d=entry1.getValue(); 
		    System.out.println("  "+d.getId()+"  "+d.getName());   
		}  
		    
		    
	}

}
