function reg(){
	
	var userName=document.form.username.value;
	var password=document.form.password.value;
	var confirmpassword=document.form.confirmpassword.value;
	
	if(userName==""||userName==null){
		alert("Enter UserName");
		return false;
	}

else if(password==""||password==null){
	alert("Enter Password");
	return false;
}
else if(confirmpassword==""||confirmpassword==null){
	alert("Enter confirmpassword");
	return false;
}
else if(confirmpassword!=password||confirmpassword==null){
	alert("Enter same Password");
	return false;
}
}


function regvalidate(){
	
	var userName=document.form.username.value;
	var password=document.form.password.value;
	
	
	if(userName==""||userName==null){
		alert("Enter UserName");
		return false;
	}

else if(password==""||password==null){
	alert("Enter Password");
	return false;
}

}