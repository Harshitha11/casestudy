package com.dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.RegisterPage;

public class RegisterDAO {
	
	static String serverName = "inchnilpdb03.india.tcs.com";
	static String portNumber = "1521";
	static String sid = "javadb03";
	static String url = "jdbc:oracle:thin:@" + serverName + ":" + portNumber + ":" + sid;
	static String username =  "E1295187"; 
	static String password = "E1295187"; 
	static PreparedStatement pst = null;
	static Statement s=null;
	static Connection con=null;
	ResultSet rst=null;
	
	public static int add(RegisterPage user) throws SQLException, ClassNotFoundException
	{
		
		int id=0;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		con =DriverManager.getConnection( url, username, password );
		pst = con.prepareStatement("insert into regtbl1 values(?,?,?,?,?,?,?)");
		pst.setString(1,user.getUsername());
		pst.setString(2,user.getPassword());
		pst.setString(3,user.getConfirmpassword());
		pst.setString(4, user.getEmail());
		pst.setString(5,user.getGender());
		pst.setString(6,user.getSkills());
		pst.setString(7,user.getLocation());
		
		id= pst.executeUpdate();
		
		if(id>0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
		
		
	}

public ArrayList<RegisterPage> getDetails() throws SQLException{
	
	ArrayList<RegisterPage> list=new ArrayList<>();
	RegisterPage rg=new RegisterPage();
	
	
	pst=con.prepareStatement("select * from regtbl1");
	
	rst=pst.executeQuery();
	while(rst.next()){
		rg.setUsername(rst.getString(1));
		rg.setEmail(rst.getString(4));
		rg.setGender(rst.getString(5));
		rg.setSkills(rst.getString(6));
		rg.setLocation(rst.getString(7));
		
		list.add(rg);
		
	}
	return list;
	
}

}
