package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.RegisterPage;
import com.dao.RegisterDAO;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		if(action.equals("Register"))
		{
			
			
		    String username=request.getParameter("username");
		  
		    String password=request.getParameter("password");
		    String confirmpassword=request.getParameter("confirmpassword");
		    String email=request.getParameter("email");
		    String gender=request.getParameter("gender");
		    String skills=request.getParameter("skills");
		    String location=request.getParameter("location");
		  
		    
		   RegisterPage reg=new RegisterPage();
		   reg.setUsername(username);
		   reg.setPassword(password);
		   reg.setConfirmpassword(confirmpassword);
		   reg.setEmail(email);
		   reg.setGender(gender);
		   reg.setSkills(skills);
		   reg.setLocation(location);
		   int status;
		try {
			status = RegisterDAO.add(reg);
			if(status>0){  
	        	RequestDispatcher rd=request.getRequestDispatcher("Success.jsp");
	        	
	        
	        	rd.forward(request, response);
	        }else{  
	        	
	        	//request.setAttribute("err","Unable to inser");
	           System.out.println("Unable to insert");
	        }  
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		}
	        
		  if(action.equals("view")){
			
			  RegisterDAO dao=new RegisterDAO();
			 try {
				ArrayList<RegisterPage> list=dao.getDetails();
				RegisterPage r=list.get(0);
			
				request.setAttribute("username",r.getUsername());
	        	
	        	request.setAttribute("email",r.getEmail());
	        	request.setAttribute("gender",r.getGender());
	        	request.setAttribute("skills",r.getSkills());
	        	request.setAttribute("location", r.getLocation());
	        	  RequestDispatcher rd=request.getRequestDispatcher("view.jsp");
	        	rd.forward(request, response);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  }
		   if(action.equals("submit"))
		   {
			   RequestDispatcher rd1=request.getRequestDispatcher("Success1.jsp");
			   rd1.forward(request, response);
		   }
		  
			  
		   }
			
		}


