package com.bean;

public class RegisterPage {
	
	
	private String username;
	private String password;
	private String confirmpassword;
	private String email;
	private String gender;
	private String skills;
	private String location;
	
	
	
	public RegisterPage(String username, String password,
			String confirmpassword, String email, String gender, String skills,
			String location) {
		super();
		this.username = username;
		this.password = password;
		this.confirmpassword = confirmpassword;
		this.email = email;
		this.gender = gender;
		this.skills = skills;
		this.location = location;
		
	}


	public RegisterPage() {
		// TODO Auto-generated constructor stub
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConfirmpassword() {
		return confirmpassword;
	}


	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getSkills() {
		return skills;
	}


	public void setSkills(String skills) {
		this.skills = skills;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	
	
	
	
	

}
